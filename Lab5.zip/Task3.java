import javax.swing.JOptionPane;

public class Task3
{
    public static void main(String[] args) {

        box Cupboard = new box();

        String input1 = JOptionPane.showInputDialog(null, "Length : ");
        Cupboard.len = Float.parseFloat(input1);

        String input2 = JOptionPane.showInputDialog(null, "Width : ");
        Cupboard.wid = Float.parseFloat(input2);

        String input3 = JOptionPane.showInputDialog(null, "Height : ");
        Cupboard.hig = Float.parseFloat(input3);


        JOptionPane.showMessageDialog(null, "Volume : " + Cupboard.volume());
        //System.out.print("Volume : " + vol);

        String input4 = JOptionPane.showInputDialog(null, "New Height : ");
        float nH = Float.parseFloat(input4);

        String input5 = JOptionPane.showInputDialog(null, "New Width : ");
        float nW = Float.parseFloat(input4);

        String input6 = JOptionPane.showInputDialog(null, "New Length : ");
        float nL = Float.parseFloat(input4);

        Cupboard.upHeight(nH);
        JOptionPane.showMessageDialog(null, "Volume with only new Height: " + Cupboard.volume());

        Cupboard.upBox(nH, nW, nL);
        JOptionPane.showMessageDialog(null, "Volume with new box : " + Cupboard.volume());



    }
}
