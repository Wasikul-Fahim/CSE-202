import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float length, height, width;
        System.out.print("Length : ");
        length = sc.nextFloat();
        System.out.print("Height : ");
        height = sc.nextFloat();
        System.out.print("Width : ");
        width =sc.nextFloat();

        box Cupboard = new box(length, width, height);
        float volume = Cupboard.volume();

        System.out.print("Volume : " + volume);
    }
}