import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float length, height, width;
        System.out.print("Length : ");
        length = sc.nextFloat();
        System.out.print("Height : ");
        height = sc.nextFloat();
        System.out.print("Width : ");
        width =sc.nextFloat();

        box Cupboard = new box();
        Cupboard.hig = height;
        Cupboard.wid = width;
        Cupboard.len = length;

        float vol = Cupboard.volume();

        System.out.print("Volume : " + vol);
    }
}