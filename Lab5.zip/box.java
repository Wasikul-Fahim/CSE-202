public class box
{
    float len, hig, wid;
    box(float length, float width, float height)
    {
        len = length;
        wid = width;
        hig = height;
    }
    box()
    {

    }
    void upBox(float newHeight, float newWidth, float newLength)
    {
        hig = newHeight;
        len = newLength;
        wid = newWidth;
    }

    void upHeight(float newHeight)
    {
        hig = newHeight;
    }

    void upWidth(float newWidth)
    {
        wid = newWidth;

    }

    void upLength(float newLength)
    {
        len = newLength;
    }

    float volume()
    {
        float vol = len * wid * hig;
        return vol;
    }
}
